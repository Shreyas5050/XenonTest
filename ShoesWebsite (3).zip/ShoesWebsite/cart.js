let products=[
    {
        name:"Nike",
        price:3999,
        Image:"sport3.jpg"
    },
    {
        name:'Puma',
        price:2999,
        Image:"sport3.jpg"
    },
    {
        name:'Nike',
        price:1799,
        Image:"sport3.jpg"
    },
    {
        name:'Nike',
        price:2099,
        Image:"sport3.jpg"
    },
    {
        name:'Lancer',
        price:599,
        Image:"sport3.jpg"
    },
    {
        name:'Nike',
        price:2299,
        Image:"sport3.jpg"
    },
    {
        name:'Addidas',
        price:2199,
        Image:"sport3.jpg"
    },
    {
        name:'Nike',
        price:3999,
        Image:"sport3.jpg"
    },
    {
        name:'LEE-COOPER',
        price:3999,
        Image:"sport3.jpg"
    },
    {
        name:'Action',
        price:999,
        Image:"sport3.jpg"
    },
    {
        name:'Converse',
        price:2599,
        Image:"sport3.jpg"
    },
    {
        name:'Adidas',
        price:2199,
        Image:"sport3.jpg"
    },
    {
        name:'Relaxo',
        price:3999,
        Image:"sport3.jpg"
    },
    {
        name:'Campus',
        price:3999,
        Image:"sport3.jpg"
    },
    {
        name:'Metro',
        price:3999,
        Image:"sport3.jpg"
    },
    {
        name:'Us-Polo',
        price:3999,
        Image:"sport3.jpg"
    },
    {
        name:'Red-Chief',
        price:3999,                     
        Image:"sport3.jpg"
    },
    {
        name:'Woodland',
        price:3999,
        Image:"sport3.jpg"
    },
    {
        name:'Sneakers',
        price:3999,
        Image:"sport3.jpg"
    },
    {
        name:'Reebook',
        price:3999,
        Image:"sport3.jpg"
    },
    {
        name:'Nike',
        price:2999,
        Image:"sport3.jpg"
    },
    {
        name:'Adidas',
        price:2999,
        Image:"sport3.jpg"
    },
    {
        name:'Kappa',
        price:2099,
        Image:"sport3.jpg"
    },
    {
        name:'HUSH-PUPPIES',
        price:2999,
        Image:"sport3.jpg"
    },
    {
        name:'LEE-COOPER',
        price:1999,
        Image:"sport3.jpg"
    },
    {
        name:'METRO',
        price:3999,
        Image:"sport3.jpg"
    },
    {
        name:'BATA',
        price:999,
        Image:"sport3.jpg"
    },
    {
        name:'Mochi',
        price:1299,
        Image:"sport3.jpg"
    },
    {
        name:'Red-Tape',
        price:999,
        Image:"sport3.jpg"
    }
   
    
];

let cart=document.querySelectorAll(".addToCart");
console.log(cart);

for(let i=0;i<cart.length;i++){
    cart[i].addEventListener("click",()=>{
        cartNumbers(products[i]);
        totalCost(products[i]);
        console.log("Pranav");
    });
}
function cartNumbers(product){

    let productNumbers=localStorage.setItem("cartNumbers");
    productNumbers=parseInt(productNumbers);
    console.log("Numberfunction")
    if(productNumbers){
        localStorage.setItem("cartNumbers",productNumbers +1);
    document.querySelector(".countItem").textContent=productNumbers +1;
    console.log("Numberfunction")
    }else{
        localStorage.setItem("cartNumbers", 1);
        document.querySelector(".countItem").textContent =1;
    }
    console.log("Numberfunction")
}
function totalCost(product){

    let cartCost= localStorage.getItem("totalCost");

    if(cartCost!=null){
        cartCost=parseInt(cartCost);
        localStorage.setItem("totalCost",cartCost + product.price);
    }else{
        localStorage.setItem("totalCost", product.price);
    }
}

// let cart = document.querySelectorAll(".addToCart");

// for (let i = 0; i < cart.length; i++) {
//   cart[i].addEventListener("click", () => {
//     cartNumbers(products[i]);
//     totalCost(products[i]);
//   });
// }

// function cartNumbers(product) {
//   let productNumbers = localStorage.getItem("cartNumbers");
//   productNumbers = parseInt(productNumbers);

//   if (productNumbers) {
//     localStorage.setItem("cartNumbers", productNumbers + 1);
//     document.querySelector(".countItem").textContent = productNumbers + 1;
//   } else {
//     localStorage.setItem("cartNumbers", 1);
//     document.querySelector(".countItem").textContent = 1;
//   }
// }

// function totalCost(product) {
//   let cartCost = localStorage.getItem("totalCost");

//   if (cartCost != null) {
//     cartCost = parseInt(cartCost);
//     localStorage.setItem("totalCost", cartCost + product.price);
//   } else {
//     localStorage.setItem("totalCost", product.price);
//   }
// }